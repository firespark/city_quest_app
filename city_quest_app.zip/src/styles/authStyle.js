import { StyleSheet } from 'react-native'

export const authStyle = StyleSheet.create({

    authCardContent: {
        paddingHorizontal: 10,
        paddingVertical: 25,
    },
    authScrollContent: {
        flexGrow: 1,
        justifyContent: 'center',
        paddingHorizontal: 10,
        paddingVertical: 20,
    },
    authContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
        paddingHorizontal: 0,
    },
    socialContainer: {
        marginTop: 30,
        width: '100%',
        gap: 12,
    },
    socialDividerRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 13,
    },
    socialDividerText: {
        marginHorizontal: 15,
        color: '#BDC3C7',
        fontWeight: '600',
    },
    socialLine: {
        flex: 1,
        height: 1,
        backgroundColor: '#F1F5F9',
    },
    socialButton: {
        height: 56,
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
        borderRadius: 28,
    },
    vkButton: {
        backgroundColor: '#0077FF',
    },
    vkButtonText: {
        color: '#FFFFFF',
        fontSize: 16,
        fontWeight: '700',
    },
    yandexButton: {
        backgroundColor: '#FFFFFF',
        borderWidth: 1,
        borderColor: '#E6E8EB',
    },
    yandexButtonText: {
        color: '#111111',
        fontSize: 16,
        fontWeight: '700',
    },
    googleContainer: {
        marginTop: 30,
        width: '100%'
    },
    googleDividerRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 25
    },
    googleButton: {
        flexDirection: 'row',
        backgroundColor: '#FFFFFF',
        borderWidth: 1,
        borderColor: '#F1F5F9',
        borderRadius: 28,
        height: 56,
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
    },
    googleButtonText: {
        fontSize: 16,
        fontWeight: '700',
        color: '#2C3E50'
    },
    googleDividerText: {
        marginHorizontal: 15,
        color: '#BDC3C7',
        fontWeight: '600'
    },
    authIcon: {
        width: 48,
        height: 48,
        margin: 7,
    },
    googleIcon: {
        width: 24,
        height: 24,
        marginRight: 12
    },
    googleLine: {
        flex: 1,
        height: 1,
        backgroundColor: '#F1F5F9'
    },
    eyePadding: {
        paddingRight: 50,
    },
    eyeSign: {
        position: 'absolute',
        right: 15,
        height: 56,
        justifyContent: 'center',
    },

});
